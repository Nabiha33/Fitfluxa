package com.example.fitfluxa; // Replace with your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Medications extends AppCompatActivity {

    private CheckBox vitaminsCheckBox, hormonesCheckBox, antibioticsCheckBox,
            anxietyCheckBox, noneCheckBox;
    private EditText otherMedicationEditText;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medications);

        vitaminsCheckBox = findViewById(R.id.vitaminsCheckBox);
        hormonesCheckBox = findViewById(R.id.hormonesCheckBox);
        antibioticsCheckBox = findViewById(R.id.antibioticsCheckBox);
        anxietyCheckBox = findViewById(R.id.anxietyCheckBox);
        noneCheckBox = findViewById(R.id.noneCheckBox);
        otherMedicationEditText = findViewById(R.id.otherMedicationEditText);
        nextButton = findViewById(R.id.nextButton);

        loadPreferences();

        // Deselect others when 'None' is selected
        noneCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                vitaminsCheckBox.setChecked(false);
                hormonesCheckBox.setChecked(false);
                antibioticsCheckBox.setChecked(false);
                anxietyCheckBox.setChecked(false);
                otherMedicationEditText.setText("");
            }
        });

        nextButton.setOnClickListener(v -> {
            savePreferences();
            Intent intent = new Intent(Medications.this, Customizedprogram.class); // Replace with your next screen
            startActivity(intent);
        });
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences("MedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("vitamins", vitaminsCheckBox.isChecked());
        editor.putBoolean("hormones", hormonesCheckBox.isChecked());
        editor.putBoolean("antibiotics", antibioticsCheckBox.isChecked());
        editor.putBoolean("anxiety", anxietyCheckBox.isChecked());
        editor.putBoolean("none", noneCheckBox.isChecked());
        editor.putString("other", otherMedicationEditText.getText().toString().trim());

        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences("MedPrefs", MODE_PRIVATE);

        vitaminsCheckBox.setChecked(prefs.getBoolean("vitamins", false));
        hormonesCheckBox.setChecked(prefs.getBoolean("hormones", false));
        antibioticsCheckBox.setChecked(prefs.getBoolean("antibiotics", false));
        anxietyCheckBox.setChecked(prefs.getBoolean("anxiety", false));
        noneCheckBox.setChecked(prefs.getBoolean("none", false));
        otherMedicationEditText.setText(prefs.getString("other", ""));
    }
}
