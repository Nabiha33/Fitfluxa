package com.example.fitfluxa; // Replace with your actual package name

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Meatpreferences extends AppCompatActivity {

    private CheckBox chickenCheckBox, fishCheckBox, beefCheckBox,
            lambCheckBox, porkCheckBox, turkeyCheckBox, duckCheckBox;
    private EditText customMeatEditText;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meatpreferences);

        // Initialize checkboxes
        chickenCheckBox = findViewById(R.id.chickenCheckBox);
        fishCheckBox = findViewById(R.id.fishCheckBox);
        beefCheckBox = findViewById(R.id.beefCheckBox);
        lambCheckBox = findViewById(R.id.lambCheckBox);
        porkCheckBox = findViewById(R.id.porkCheckBox);
        turkeyCheckBox = findViewById(R.id.turkeyCheckBox);
        duckCheckBox = findViewById(R.id.duckCheckBox);

        // Initialize EditText and Button
        customMeatEditText = findViewById(R.id.customMeatEditText);
        nextButton = findViewById(R.id.nextButton);

        // Load saved preferences
        loadPreferences();

        // Save and navigate
        nextButton.setOnClickListener(v -> {
            savePreferences();
            Intent intent = new Intent(Meatpreferences.this, Medications.class); // Replace with your next activity
            startActivity(intent);
        });
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences("MeatPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("chicken", chickenCheckBox.isChecked());
        editor.putBoolean("fish", fishCheckBox.isChecked());
        editor.putBoolean("beef", beefCheckBox.isChecked());
        editor.putBoolean("lamb", lambCheckBox.isChecked());
        editor.putBoolean("pork", porkCheckBox.isChecked());
        editor.putBoolean("turkey", turkeyCheckBox.isChecked());
        editor.putBoolean("duck", duckCheckBox.isChecked());
        editor.putString("customMeat", customMeatEditText.getText().toString().trim());

        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences("MeatPrefs", MODE_PRIVATE);

        chickenCheckBox.setChecked(prefs.getBoolean("chicken", false));
        fishCheckBox.setChecked(prefs.getBoolean("fish", false));
        beefCheckBox.setChecked(prefs.getBoolean("beef", false));
        lambCheckBox.setChecked(prefs.getBoolean("lamb", false));
        porkCheckBox.setChecked(prefs.getBoolean("pork", false));
        turkeyCheckBox.setChecked(prefs.getBoolean("turkey", false));
        duckCheckBox.setChecked(prefs.getBoolean("duck", false));
        customMeatEditText.setText(prefs.getString("customMeat", ""));
    }
}
