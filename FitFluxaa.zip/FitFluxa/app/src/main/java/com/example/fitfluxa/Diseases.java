package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class Diseases extends AppCompatActivity {

    private CheckBox diabetesCheckBox, hypertensionCheckBox, thyroidCheckBox,
            heartCheckBox, kidneyCheckBox, gutCheckBox, pcosCheckBox;
    private EditText customConditionEditText;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diseases);

        diabetesCheckBox = findViewById(R.id.diabetesCheckBox);
        hypertensionCheckBox = findViewById(R.id.hypertensionCheckBox);
        thyroidCheckBox = findViewById(R.id.thyroidCheckBox);
        heartCheckBox = findViewById(R.id.heartCheckBox);
        kidneyCheckBox = findViewById(R.id.kidneyCheckBox);
        gutCheckBox = findViewById(R.id.gutCheckBox);
        pcosCheckBox = findViewById(R.id.pcosCheckBox);
        customConditionEditText = findViewById(R.id.customConditionEditText);
        nextButton = findViewById(R.id.nextButton);

        loadPreferences();

        nextButton.setOnClickListener(v -> {
            savePreferences();
            Intent intent = new Intent(Diseases.this, Foodpreferences.class); // Change to your actual next screen
            startActivity(intent);
        });
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences("HealthPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("diabetes", diabetesCheckBox.isChecked());
        editor.putBoolean("hypertension", hypertensionCheckBox.isChecked());
        editor.putBoolean("thyroid", thyroidCheckBox.isChecked());
        editor.putBoolean("heart", heartCheckBox.isChecked());
        editor.putBoolean("kidney", kidneyCheckBox.isChecked());
        editor.putBoolean("gut", gutCheckBox.isChecked());
        editor.putBoolean("pcos", pcosCheckBox.isChecked());
        editor.putString("customCondition", customConditionEditText.getText().toString().trim());

        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences("HealthPrefs", MODE_PRIVATE);

        diabetesCheckBox.setChecked(prefs.getBoolean("diabetes", false));
        hypertensionCheckBox.setChecked(prefs.getBoolean("hypertension", false));
        thyroidCheckBox.setChecked(prefs.getBoolean("thyroid", false));
        heartCheckBox.setChecked(prefs.getBoolean("heart", false));
        kidneyCheckBox.setChecked(prefs.getBoolean("kidney", false));
        gutCheckBox.setChecked(prefs.getBoolean("gut", false));
        pcosCheckBox.setChecked(prefs.getBoolean("pcos", false));
        customConditionEditText.setText(prefs.getString("customCondition", ""));
    }
}
