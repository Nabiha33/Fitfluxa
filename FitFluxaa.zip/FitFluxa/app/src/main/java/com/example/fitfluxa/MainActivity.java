package com.example.fitfluxa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnLoseWeight, btnManageCondition, btnIncreaseEnergy, btnHealthyLifestyle, btnContinue;
    TextView tvWelcome, tvHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Make sure this matches your XML filename

        // Initialize views
        tvWelcome = findViewById(R.id.tv1);
        tvHint = findViewById(R.id.tv);
        btnLoseWeight = findViewById(R.id.btn_lose_weight);
        btnManageCondition = findViewById(R.id.btn_manage_condition);
        btnIncreaseEnergy = findViewById(R.id.btn_increase_energy);
        btnHealthyLifestyle = findViewById(R.id.btn_healthy_lifestyle);
        btnContinue = findViewById(R.id.btn_continue);

        // Continue button navigates to IntoleranceActivity
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Intolerence.class);
                startActivity(intent);
            }
        });
    }
}
