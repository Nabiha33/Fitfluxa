package com.example.fitfluxa;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.fitfluxa.LoginActivity;

public class SplashActivity extends Activity {

    private static final int SPLASH_DISPLAY_LENGTH = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash); // replace with your actual layout file name

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start next activity
                Intent mainIntent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(mainIntent);
                finish(); // close splash so user can't go back to it
            }
        }, SPLASH_DISPLAY_LENGTH);
    }
}
