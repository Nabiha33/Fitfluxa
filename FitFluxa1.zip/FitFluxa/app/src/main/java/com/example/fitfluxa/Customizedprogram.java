package com.example.fitfluxa;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Customizedprogram extends AppCompatActivity {

    private TextView programTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customizedprogram);

        programTextView = findViewById(R.id.programTextView);
        String program = generateCustomizedProgram();
        programTextView.setText(program);
    }

    private String generateCustomizedProgram() {
        SharedPreferences foodPrefs = getSharedPreferences("FoodPrefs", MODE_PRIVATE);
        SharedPreferences medPrefs = getSharedPreferences("MedPrefs", MODE_PRIVATE);
        SharedPreferences diseasePrefs = getSharedPreferences("DiseasePrefs", MODE_PRIVATE);
        SharedPreferences activityPrefs = getSharedPreferences("ActivityPrefs", MODE_PRIVATE);
        SharedPreferences goalPrefs = getSharedPreferences("GoalPrefs", MODE_PRIVATE);

        StringBuilder plan = new StringBuilder("Your Personalized Diet Program:\n\n");

        // Example: Food preference
        if (foodPrefs.getBoolean("vegan", false)) {
            plan.append("• Focus on plant-based meals with tofu, lentils, and quinoa.\n");
        } else if (foodPrefs.getBoolean("vegetarian", false)) {
            plan.append("• Include eggs, dairy, and lots of vegetables and legumes.\n");
        } else if (foodPrefs.getBoolean("nonVegetarian", false)) {
            plan.append("• Balanced meals with lean meats like chicken and fish.\n");
        }

        // Example: Intolerances (you'd retrieve these from your own prefs or DB)
        SharedPreferences intolerancePrefs = getSharedPreferences("IntolerancePrefs", MODE_PRIVATE);
        if (intolerancePrefs.getBoolean("lactose", false)) {
            plan.append("• Avoid milk and switch to lactose-free or plant-based alternatives.\n");
        }
        if (intolerancePrefs.getBoolean("gluten", false)) {
            plan.append("• Use gluten-free grains like rice, millet, and quinoa.\n");
        }

        // Example: Medications
        if (medPrefs.getBoolean("antibiotics", false)) {
            plan.append("• Add probiotic foods like yogurt to help gut health.\n");
        }
        if (medPrefs.getBoolean("anxiety", false)) {
            plan.append("• Include magnesium-rich foods like spinach, nuts, and bananas.\n");
        }

        // Example: Diseases
        if (diseasePrefs.getBoolean("diabetes", false)) {
            plan.append("• Limit sugar and refined carbs. Include more fiber-rich foods.\n");
        }
        if (diseasePrefs.getBoolean("thyroid", false)) {
            plan.append("• Avoid goitrogens in excess. Include selenium and iodine-rich foods.\n");
        }

        // Example: Physical Activity
        String activityLevel = activityPrefs.getString("activity_level", "moderate");
        if (activityLevel.equals("high")) {
            plan.append("• Include more protein and complex carbs to support your workouts.\n");
        } else if (activityLevel.equals("low")) {
            plan.append("• Opt for lighter meals and ensure daily movement.\n");
        }

        // Example: Goal
        String goal = goalPrefs.getString("goal", "maintain");
        switch (goal) {
            case "lose":
                plan.append("• Calorie deficit plan with high fiber and protein.\n");
                break;
            case "gain":
                plan.append("• Calorie surplus with protein-rich snacks.\n");
                break;
            case "maintain":
            default:
                plan.append("• Balanced intake to maintain your current weight.\n");
                break;
        }

        plan.append("\nAlways consult a certified dietitian for detailed guidance.");

        return plan.toString();
    }
}
