package com.example.fitfluxa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

// ----------------------------------------

class NextActivity extends AppCompatActivity {

    private TextView tvSelectedGoals;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Simple TextView UI created programmatically
        tvSelectedGoals = new TextView(this);
        tvSelectedGoals.setPadding(24, 24, 24, 24);
        tvSelectedGoals.setTextSize(18f);

        setContentView(tvSelectedGoals);

        // Get selected goals from intent extras
        String goals = getIntent().getStringExtra("selected_goals");
        if (goals == null || goals.isEmpty()) {
            tvSelectedGoals.setText("No goals selected.");
        } else {
            tvSelectedGoals.setText("You selected the following goals:\n" + goals.replace(",", "\n"));
        }
    }
}
