package com.example.fitfluxa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class GoalSelectionActivity extends AppCompatActivity {

    private ImageView ivBack;
    private MaterialButton btnLoseWeight, btnManageCondition, btnIncreaseEnergy, btnHealthyLifestyle, btnContinue;

    private boolean loseWeightSelected = false;
    private boolean manageConditionSelected = false;
    private boolean increaseEnergySelected = false;
    private boolean healthyLifestyleSelected = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Replace with your layout file name

        ivBack = findViewById(R.id.iv_back);
        btnLoseWeight = findViewById(R.id.btn_lose_weight);
        btnManageCondition = findViewById(R.id.btn_manage_condition);
        btnIncreaseEnergy = findViewById(R.id.btn_increase_energy);
        btnHealthyLifestyle = findViewById(R.id.btn_healthy_lifestyle);
        btnContinue = findViewById(R.id.btn_continue);

        ivBack.setOnClickListener(v -> onBackPressed());

        btnLoseWeight.setOnClickListener(v -> {
            loseWeightSelected = !loseWeightSelected;
            updateButtonState(btnLoseWeight, loseWeightSelected);
        });

        btnManageCondition.setOnClickListener(v -> {
            manageConditionSelected = !manageConditionSelected;
            updateButtonState(btnManageCondition, manageConditionSelected);
        });

        btnIncreaseEnergy.setOnClickListener(v -> {
            increaseEnergySelected = !increaseEnergySelected;
            updateButtonState(btnIncreaseEnergy, increaseEnergySelected);
        });

        btnHealthyLifestyle.setOnClickListener(v -> {
            healthyLifestyleSelected = !healthyLifestyleSelected;
            updateButtonState(btnHealthyLifestyle, healthyLifestyleSelected);
        });

        btnContinue.setOnClickListener(v -> continueWithSelections());
    }

    private void updateButtonState(MaterialButton button, boolean selected) {
        if (selected) {
            button.setBackgroundColor(getResources().getColor(android.R.color.holo_purple)); // selected color
            button.setTextColor(getResources().getColor(android.R.color.white));
        } else {
            button.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark)); // original color
            button.setTextColor(getResources().getColor(android.R.color.white));
        }
    }

    private void continueWithSelections() {
        if (!loseWeightSelected && !manageConditionSelected && !increaseEnergySelected && !healthyLifestyleSelected) {
            Toast.makeText(this, "Please select at least one goal.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prepare a string listing selected goals
        StringBuilder selectedGoals = new StringBuilder();
        if (loseWeightSelected) selectedGoals.append("Lose Weight,");
        if (manageConditionSelected) selectedGoals.append("Manage a Health Condition,");
        if (increaseEnergySelected) selectedGoals.append("Increase Energy,");
        if (healthyLifestyleSelected) selectedGoals.append("Live a Healthy Lifestyle,");

        // Remove trailing comma
        if (selectedGoals.length() > 0) selectedGoals.deleteCharAt(selectedGoals.length() - 1);

        // Start NextActivity and pass selected goals as extra
        Intent intent = new Intent(this, Intolerence.class);
        intent.putExtra("selected_goals", selectedGoals.toString());
        startActivity(intent);
    }
}
