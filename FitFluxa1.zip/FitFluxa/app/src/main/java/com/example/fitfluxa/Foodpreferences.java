package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Foodpreferences extends AppCompatActivity {

    private CheckBox vegetarianCheckBox, nonVegCheckBox, veganCheckBox,
            eggetarianCheckBox, pescatarianCheckBox;
    private EditText customFoodEditText;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodpreferences);

        vegetarianCheckBox = findViewById(R.id.vegetarianCheckBox);
        nonVegCheckBox = findViewById(R.id.nonVegCheckBox);
        veganCheckBox = findViewById(R.id.veganCheckBox);
        eggetarianCheckBox = findViewById(R.id.eggetarianCheckBox);
        pescatarianCheckBox = findViewById(R.id.pescatarianCheckBox);
        customFoodEditText = findViewById(R.id.customFoodEditText);
        nextButton = findViewById(R.id.nextButton);

        loadPreferences();

        nextButton.setOnClickListener(v -> {
            savePreferences();
            Intent intent = new Intent(Foodpreferences.this, Meatpreferences.class); // Replace with actual next screen
            startActivity(intent);
        });
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences("FoodPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("vegetarian", vegetarianCheckBox.isChecked());
        editor.putBoolean("nonVegetarian", nonVegCheckBox.isChecked());
        editor.putBoolean("vegan", veganCheckBox.isChecked());
        editor.putBoolean("eggetarian", eggetarianCheckBox.isChecked());
        editor.putBoolean("pescatarian", pescatarianCheckBox.isChecked());
        editor.putString("customFood", customFoodEditText.getText().toString().trim());

        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences("FoodPrefs", MODE_PRIVATE);

        vegetarianCheckBox.setChecked(prefs.getBoolean("vegetarian", false));
        nonVegCheckBox.setChecked(prefs.getBoolean("nonVegetarian", false));
        veganCheckBox.setChecked(prefs.getBoolean("vegan", false));
        eggetarianCheckBox.setChecked(prefs.getBoolean("eggetarian", false));
        pescatarianCheckBox.setChecked(prefs.getBoolean("pescatarian", false));
        customFoodEditText.setText(prefs.getString("customFood", ""));
    }
}
