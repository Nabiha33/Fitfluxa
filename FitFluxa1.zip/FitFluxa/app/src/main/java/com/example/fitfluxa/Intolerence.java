package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Intolerence extends AppCompatActivity {

    private CheckBox glutenCheckBox, lactoseCheckBox, nutsCheckBox, soyCheckBox,
            eggsCheckBox, shellfishCheckBox, fishCheckBox, sesameCheckBox, mustardCheckBox;
    private EditText customIntoleranceEditText;
    private Button saveButton, nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intolerence);

        glutenCheckBox = findViewById(R.id.glutenCheckBox);
        lactoseCheckBox = findViewById(R.id.lactoseCheckBox);
        nutsCheckBox = findViewById(R.id.nutsCheckBox);
        soyCheckBox = findViewById(R.id.soyCheckBox);
        eggsCheckBox = findViewById(R.id.eggsCheckBox);
        shellfishCheckBox = findViewById(R.id.shellfishCheckBox);
        fishCheckBox = findViewById(R.id.fishCheckBox);
        sesameCheckBox = findViewById(R.id.sesameCheckBox);
        mustardCheckBox = findViewById(R.id.mustardCheckBox);
        customIntoleranceEditText = findViewById(R.id.customIntoleranceEditText);

        nextButton = findViewById(R.id.nextButton);

        loadPreferences();

        saveButton.setOnClickListener(v -> {
            savePreferences();
            Toast.makeText(this, "Preferences saved", Toast.LENGTH_SHORT).show();
        });

        nextButton.setOnClickListener(v -> {
            savePreferences();  // Optional: save before navigating
            Intent intent = new Intent(Intolerence.this, Physicalactivities.class);
            startActivity(intent);
        });
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences("FoodPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("gluten", glutenCheckBox.isChecked());
        editor.putBoolean("lactose", lactoseCheckBox.isChecked());
        editor.putBoolean("nuts", nutsCheckBox.isChecked());
        editor.putBoolean("soy", soyCheckBox.isChecked());
        editor.putBoolean("eggs", eggsCheckBox.isChecked());
        editor.putBoolean("shellfish", shellfishCheckBox.isChecked());
        editor.putBoolean("fish", fishCheckBox.isChecked());
        editor.putBoolean("sesame", sesameCheckBox.isChecked());
        editor.putBoolean("mustard", mustardCheckBox.isChecked());
        editor.putString("custom", customIntoleranceEditText.getText().toString().trim());

        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences("FoodPrefs", MODE_PRIVATE);

        glutenCheckBox.setChecked(prefs.getBoolean("gluten", false));
        lactoseCheckBox.setChecked(prefs.getBoolean("lactose", false));
        nutsCheckBox.setChecked(prefs.getBoolean("nuts", false));
        soyCheckBox.setChecked(prefs.getBoolean("soy", false));
        eggsCheckBox.setChecked(prefs.getBoolean("eggs", false));
        shellfishCheckBox.setChecked(prefs.getBoolean("shellfish", false));
        fishCheckBox.setChecked(prefs.getBoolean("fish", false));
        sesameCheckBox.setChecked(prefs.getBoolean("sesame", false));
        mustardCheckBox.setChecked(prefs.getBoolean("mustard", false));
        customIntoleranceEditText.setText(prefs.getString("custom", ""));
    }
}
