package com.example.fitfluxa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class Physicalactivities extends AppCompatActivity {

    private CheckBox walkingCheckBox, runningCheckBox, cyclingCheckBox,
            swimmingCheckBox, gymCheckBox, yogaCheckBox, sportsCheckBox;
    private EditText customActivityEditText;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_physicalactivities);

        walkingCheckBox = findViewById(R.id.walkingCheckBox);
        runningCheckBox = findViewById(R.id.runningCheckBox);
        cyclingCheckBox = findViewById(R.id.cyclingCheckBox);
        swimmingCheckBox = findViewById(R.id.swimmingCheckBox);
        gymCheckBox = findViewById(R.id.gymCheckBox);
        yogaCheckBox = findViewById(R.id.yogaCheckBox);
        sportsCheckBox = findViewById(R.id.sportsCheckBox);
        customActivityEditText = findViewById(R.id.customActivityEditText);
        nextButton = findViewById(R.id.nextButton);

        loadPreferences();

        nextButton.setOnClickListener(v -> {
            savePreferences();
            Intent intent = new Intent(Physicalactivities.this, Diseases.class); // Replace with your next activity
            startActivity(intent);
        });
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences("ActivityPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("walking", walkingCheckBox.isChecked());
        editor.putBoolean("running", runningCheckBox.isChecked());
        editor.putBoolean("cycling", cyclingCheckBox.isChecked());
        editor.putBoolean("swimming", swimmingCheckBox.isChecked());
        editor.putBoolean("gym", gymCheckBox.isChecked());
        editor.putBoolean("yoga", yogaCheckBox.isChecked());
        editor.putBoolean("sports", sportsCheckBox.isChecked());
        editor.putString("customActivity", customActivityEditText.getText().toString().trim());

        editor.apply();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences("ActivityPrefs", MODE_PRIVATE);

        walkingCheckBox.setChecked(prefs.getBoolean("walking", false));
        runningCheckBox.setChecked(prefs.getBoolean("running", false));
        cyclingCheckBox.setChecked(prefs.getBoolean("cycling", false));
        swimmingCheckBox.setChecked(prefs.getBoolean("swimming", false));
        gymCheckBox.setChecked(prefs.getBoolean("gym", false));
        yogaCheckBox.setChecked(prefs.getBoolean("yoga", false));
        sportsCheckBox.setChecked(prefs.getBoolean("sports", false));
        customActivityEditText.setText(prefs.getString("customActivity", ""));
    }
}
